<?php

$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "book";
      
$db = new mysqli ($host, $dbusername, $dbpassword, $dbname);

?>