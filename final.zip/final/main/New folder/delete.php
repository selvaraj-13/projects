<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

  
    $sql = "DELETE FROM books WHERE id = $book_id";
    $conn->query($sql);

    
    $sql = "DELETE FROM files WHERE book_id = $book_id";
    $conn->query($sql);
}

$conn->close();

header("Location: index.php");
exit();
