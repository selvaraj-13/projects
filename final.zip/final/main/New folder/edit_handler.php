<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book_id = $_POST["book_id"];
    $book_name = $_POST["book_name"];

    $sql = "UPDATE books SET book_name = '$book_name' WHERE id = $book_id";
    $conn->query($sql);
}

$conn->close();

header("Location: index.php");
exit();
