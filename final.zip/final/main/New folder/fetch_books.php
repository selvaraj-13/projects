<?php
include 'db_connection.php';

$sql = "SELECT * FROM books";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $book_id = $row['id'];
        $book_name = $row['book_name'];

        
        $sql_image = "SELECT * FROM files WHERE book_id = $book_id AND file_type = 'image'";
        $result_image = $conn->query($sql_image);

        if ($result_image->num_rows > 0) {
            $row_image = $result_image->fetch_assoc();
            $image_path = $row_image['file_path'];
            $image_preview = "<img src='$image_path' alt='Image Preview' style='width: 700%; height: 600%;'>";
        } else {
            $image_preview = "No Image";
        }

        echo "<tr>
        <center>
                <td>{$row['id']}</td>
                <td>{$book_name}</td>
                <td>
                    <a href='edit.php?id={$book_id}'>Edit</a>
                    <a href='delete.php?id={$book_id}'>Delete</a>
                    <a href='download.php?id={$book_id}'>Download</a>
                </td>
                
                <td>{$image_preview}</td>
                </center>
            </tr>";
            
    }
} else {
    echo "<tr><td colspan='4'>No books found</td></tr>";
}

$conn->close();
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search_term"])) {
    $searchTerm = $_GET["search_term"];

    
    $sql = "SELECT * FROM books WHERE book_name LIKE '%$searchTerm%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h3>Search Results:</h3>";
    }
}

?>