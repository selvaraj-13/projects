<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Management</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <h2>Book Management</h2>
    <button><a href="upload.php">Upload New Book</a></button>
    <main>
        <form action="fetch_book.php" method="get">
            <label for="search-term">Search Books:</label>
            <input type="text" id="search-term" name="search_term" required>
            <button type="submit" name="search">Search</button>
        </form>

    </main>

    <form action="search/search_handler.php" method="get">
    
    </form>

    <table>
        <thead>
            <center>
            <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>Actions</th>
                
                <th>Image Preview</th>
                </center>
            </tr>
        </thead>
        <tbody>
            <?php include 'fetch_books.php'; ?>
        </tbody>
    </table>
    <br>
    
</body>
</html>
