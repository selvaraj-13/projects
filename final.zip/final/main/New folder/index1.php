<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Management</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <h2>Book Management</h2>
    

    <form action="search/search_handler.php" method="get">
    
    </form>

    <table>
        <thead>
            <center>
            <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>Downloads</th>
                
                <th>Image Preview</th>
                </center>
            </tr>
        </thead>
        <tbody>
            <?php include 'fetch_books1.php'; ?>
        </tbody>
    </table>
    <br>
    
</body>
</html>
