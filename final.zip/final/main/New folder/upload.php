<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Book</title>
    <link rel="stylesheet" href="style12.css">
</head>
<body>
   
    <div class="login-form">
    <h2>Upload Book</h2>
    <form action="upload_handler.php" method="post" enctype="multipart/form-data">
        <label for="book_name">Book Name:</label>
        <input type="text" name="book_name" id="book_name" required>
        <br><h1>

        </h1>



        <label for="pdf_file">Upload PDF:</label>
        <input type="file" name="pdf_file" id="pdf_file" accept=".pdf" required>
        <br>
        <h1>

        </h1>
        <label for="image_file">Upload Image:</label>
        <input type="file" name="image_file" id="image_file" accept="image/*" required>
        <br>
         <button type="submit">uplopad</button>
    </form>
  
    <br>
   <button> <a href="index.php">Back to Home</a></button>
</body>
</div>
</html>
