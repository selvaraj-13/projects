
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$uname = $_POST['name'];
$upswd = $_POST['password_hash'];

$sql = "SELECT * FROM staff WHERE name='$uname' AND password_hash='$upswd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    header("location:New folder/index1.php");
} else {
    echo "Invalid username or password";
}
$conn->close();
?>
