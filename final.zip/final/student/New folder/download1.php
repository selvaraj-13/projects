<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

    $sql = "SELECT * FROM files WHERE book_id = $book_id AND file_type = 'pdf'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $pdf_file_path = $row['file_path'];

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="downloaded.pdf"');
        header('Content-Transfer-Encoding: binary');
        header('Accept-Ranges: bytes');
        @readfile($pdf_file_path);
    }
}

$conn->close();
