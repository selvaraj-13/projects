
<?php
// Database connection (replace with your database details)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user input from the login form
$uname = $_POST['name'];
$upswd = $_POST['password_hash'];

// Validate username and password
$sql = "SELECT * FROM staff WHERE name='$uname' AND password_hash='$upswd'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    header("location:/New folder/index1.php");
} else {
    echo "Invalid username or password";
}
$conn->close();
?>
