<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $book_id = $_GET['id'];

    // Fetch book details
    $sql = "SELECT * FROM books WHERE id = $book_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $book_name = $row['book_name'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Edit Book</h2>
    <form action="edit_handler.php" method="post">
        <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
        <label for="book_name">Book Name:</label>
        <input type="text" name="book_name" id="book_name" value="<?php echo $book_name; ?>" required>
        <br>
        <input type="submit" value="Save Changes">
    </form>
    <br>
    <a href="index.php">Back to Home</a>
</body>
</html>
