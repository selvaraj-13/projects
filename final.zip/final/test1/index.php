<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Management</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <h2>Book Management</h2>
    <button><a href="upload.php">Upload New Book</a></button>

    <form action="search/search_handler.php" method="get">
    
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Book Name</th>
                <th>Actions</th>
                
                <th>Image Preview</th>
                
            </tr>
        </thead>
        <tbody>
            <?php include 'fetch_books.php'; ?>
        </tbody>
    </table>
    <br>
    
</body>
</html>
