<?php
include '../db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $search_query = $_GET["search"];

    $sql = "SELECT * FROM books WHERE book_name LIKE '%$search_query%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $book_id = $row['id'];
            $book_name = $row['book_name'];

            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$book_name}</td>
                    <td>
                        <a href='edit.php?id={$book_id}'>Edit</a>
                        <a href='delete.php?id={$book_id}'>Delete</a>
                        <a href='download.php?id={$book_id}'>Download</a>
                    </td>
                    <td>{$image_preview}</td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No books found</td></tr>";
    }
}

$conn->close();
