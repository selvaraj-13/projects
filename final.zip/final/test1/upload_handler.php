<?php
include 'db_connection.php';

$book_name = $_POST["book_name"];

// Upload PDF file
$pdf_file = "uploads/" . $_FILES["pdf_file"]["name"];
move_uploaded_file($_FILES["pdf_file"]["tmp_name"], $pdf_file);

// Upload image file
$image_file = "uploads/" . $_FILES["image_file"]["name"];
move_uploaded_file($_FILES["image_file"]["tmp_name"], $image_file);

$sql = "INSERT INTO books (book_name) VALUES ('$book_name')";
$conn->query($sql);

$book_id = $conn->insert_id;

$sql = "INSERT INTO files (book_id, file_type, file_path) VALUES ('$book_id', 'pdf', '$pdf_file')";
$conn->query($sql);

$sql = "INSERT INTO files (book_id, file_type, file_path) VALUES ('$book_id', 'image', '$image_file')";
$conn->query($sql);

$conn->close();

header("Location: index.php");
exit();
